<?php

$servername = "102.219.176.39";
$database = "cjmxjvbk_argon";
$username = "cjmxjvbk_argon";
$password = "cjmxjvbk_argon";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

